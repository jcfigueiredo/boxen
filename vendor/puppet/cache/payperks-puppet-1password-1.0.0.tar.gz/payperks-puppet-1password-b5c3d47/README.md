# 1Password for Mac

## Usage

```puppet
include 1password
```

## Required Puppet Modules

* `boxen`

