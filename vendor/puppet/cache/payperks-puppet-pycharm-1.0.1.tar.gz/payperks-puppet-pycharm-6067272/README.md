# PyCharm

## Usage

```puppet
include pycharm
```

## Required Puppet Modules

* `boxen`

